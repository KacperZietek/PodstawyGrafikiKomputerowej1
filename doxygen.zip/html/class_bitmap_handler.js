var class_bitmap_handler =
[
    [ "cleanup", "class_bitmap_handler.html#a695ba2232246e06a030beb6c0c59e5ac", null ],
    [ "createBitmap", "class_bitmap_handler.html#a10de7c7af3e5248c07501539cb4547ce", null ],
    [ "destroyBitmap", "class_bitmap_handler.html#ad00e9db696a62b4568eadc7b2ffb494d", null ],
    [ "loadBitmap", "class_bitmap_handler.html#a986c6268064fe0126b9476288da9a0a8", null ]
];