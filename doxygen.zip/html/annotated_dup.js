var annotated_dup =
[
    [ "AnimatedObject", "class_animated_object.html", null ],
    [ "BitmapHandler", "class_bitmap_handler.html", "class_bitmap_handler" ],
    [ "BitmapObject", "class_bitmap_object.html", "class_bitmap_object" ],
    [ "DrawableObject", "class_drawable_object.html", null ],
    [ "Engine", "class_engine.html", "class_engine" ],
    [ "GameObject", "class_game_object.html", null ],
    [ "LineSegment", "class_line_segment.html", null ],
    [ "Player", "class_player.html", "class_player" ],
    [ "Point2D", "class_point2_d.html", null ],
    [ "PrimitiveRenderer", "class_primitive_renderer.html", "class_primitive_renderer" ],
    [ "ShapeObject", "class_shape_object.html", "class_shape_object" ],
    [ "SpriteObject", "class_sprite_object.html", "class_sprite_object" ],
    [ "TransformableObject", "class_transformable_object.html", null ],
    [ "UpdatableObject", "class_updatable_object.html", null ]
];