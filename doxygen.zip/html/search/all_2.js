var searchData=
[
  ['cleanup_0',['cleanup',['../class_bitmap_handler.html#a695ba2232246e06a030beb6c0c59e5ac',1,'BitmapHandler::cleanup()'],['../class_engine.html#a18dcb065818c6ec7e76168452eb45001',1,'Engine::cleanup()']]],
  ['createbitmap_1',['createBitmap',['../class_bitmap_handler.html#a10de7c7af3e5248c07501539cb4547ce',1,'BitmapHandler']]],
  ['createellipse_2',['createEllipse',['../class_shape_object.html#a9f39bb223bdd03eac593f74873782110',1,'ShapeObject']]],
  ['createline_3',['createLine',['../class_shape_object.html#a24cec2d0420080831716a55c68e7dde7',1,'ShapeObject']]]
];
