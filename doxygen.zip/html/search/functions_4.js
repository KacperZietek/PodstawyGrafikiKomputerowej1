var searchData=
[
  ['getinstance_0',['getInstance',['../class_engine.html#a4fbdd2df29e30dd08de3c285cee8c128',1,'Engine']]],
  ['getposition_1',['getPosition',['../class_bitmap_object.html#a9456debb6300c06e7ae73b967a4eab39',1,'BitmapObject::getPosition()'],['../class_shape_object.html#a5b1499cbec300fb6fb7995dc0406bd6d',1,'ShapeObject::getPosition()']]]
];
