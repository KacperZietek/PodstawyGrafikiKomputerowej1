var searchData=
[
  ['loadbitmap_0',['loadBitmap',['../class_bitmap_handler.html#a986c6268064fe0126b9476288da9a0a8',1,'BitmapHandler']]]
];
