var searchData=
[
  ['update_0',['update',['../class_bitmap_object.html#a5f9b0a293f9ce786d1e856ebd015ab93',1,'BitmapObject::update()'],['../class_player.html#a9acd4c2abd2a98d54a4bc574452c20a7',1,'Player::update()'],['../class_sprite_object.html#ad6f48d8d21f53d430f33274d8e505a2d',1,'SpriteObject::update()']]]
];
