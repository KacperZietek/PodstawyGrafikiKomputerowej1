var indexSectionsWithContent =
{
  0: "abcdefgilmprstu",
  1: "abdeglpstu",
  2: "beglmps",
  3: "bcdfgilrstu",
  4: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Enumerations"
};

