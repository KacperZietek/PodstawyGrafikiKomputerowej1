var searchData=
[
  ['translate_0',['translate',['../class_bitmap_object.html#a1a33407afd6d22910e1eec842f4ed90e',1,'BitmapObject::translate()'],['../class_shape_object.html#a38e6f44da48551ac628b44934ed02343',1,'ShapeObject::translate()']]]
];
