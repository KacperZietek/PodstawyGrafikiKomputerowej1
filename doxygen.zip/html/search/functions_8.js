var searchData=
[
  ['scale_0',['scale',['../class_bitmap_object.html#aa1ab2cc7d80ce97b09bf7095f6258f4b',1,'BitmapObject::scale()'],['../class_shape_object.html#a596357e92f9a6b88158c13be3edf379b',1,'ShapeObject::scale(float k, float ox, float oy) override']]],
  ['shapeobject_1',['ShapeObject',['../class_shape_object.html#a7cf19aeb1a7b7e9d8679dae2967e4908',1,'ShapeObject']]],
  ['spriteobject_2',['SpriteObject',['../class_sprite_object.html#abbff8418047de3b9bacdb2bb53cee654',1,'SpriteObject']]]
];
