var class_bitmap_object =
[
    [ "BitmapObject", "class_bitmap_object.html#ad0639545f4dccbf765ffabb96337c297", null ],
    [ "getPosition", "class_bitmap_object.html#a9456debb6300c06e7ae73b967a4eab39", null ],
    [ "rotate", "class_bitmap_object.html#a610c849a467dbcd642d562d21b89ccfc", null ],
    [ "scale", "class_bitmap_object.html#aa1ab2cc7d80ce97b09bf7095f6258f4b", null ],
    [ "translate", "class_bitmap_object.html#a1a33407afd6d22910e1eec842f4ed90e", null ],
    [ "update", "class_bitmap_object.html#a5f9b0a293f9ce786d1e856ebd015ab93", null ]
];