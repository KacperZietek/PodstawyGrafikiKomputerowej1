var class_sprite_object =
[
    [ "SpriteObject", "class_sprite_object.html#abbff8418047de3b9bacdb2bb53cee654", null ],
    [ "draw", "class_sprite_object.html#aebbbd0623b35ab62e46ab92d7d6b4f58", null ],
    [ "update", "class_sprite_object.html#ad6f48d8d21f53d430f33274d8e505a2d", null ]
];