var class_shape_object =
[
    [ "ShapeObject", "class_shape_object.html#a7cf19aeb1a7b7e9d8679dae2967e4908", null ],
    [ "draw", "class_shape_object.html#ab02cf73515f5d4b85c468828811be14b", null ],
    [ "getPosition", "class_shape_object.html#a5b1499cbec300fb6fb7995dc0406bd6d", null ],
    [ "rotate", "class_shape_object.html#a4900f4607a1968dded294047fc636427", null ],
    [ "scale", "class_shape_object.html#a596357e92f9a6b88158c13be3edf379b", null ],
    [ "translate", "class_shape_object.html#a38e6f44da48551ac628b44934ed02343", null ]
];