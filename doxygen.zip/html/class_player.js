var class_player =
[
    [ "update", "class_player.html#a9acd4c2abd2a98d54a4bc574452c20a7", null ]
];